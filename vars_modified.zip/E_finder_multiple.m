load('vars_modified.mat')
plot_disp = 1;
plot_error = 1;
n_curves = 5;


% Material properties
Inertia.Steel = 3.77468E-10;
Inertia.Brass = 3.7258E-10;
Inertia.Alumi = 3.63855E-10;
Weight.Steel = 0.9545;
Weight.Brass = 1.0111;
Weight.Alumi = 0.321;
Range.Steel = [1E11, 2E11];
Range.Brass = [50E9, 200e9];
Range.Alumi = [25E9,150E9];

% Declaring variables
syms x

%% Inputting Data
subset = listdlg('PromptString','Select a file:',...
                      'SelectionMode','multiple',...
                      'ListString',subset_names);

results = cell(length(subset),2);               

for c = 1:length(subset)
    code = Split_data(subset(c)).Value{1};
    material = code(1:5);
    if length(code) == 12
        type = 1;
    else
        type = 2;
        if code(14) == '2'
            P = 0.62784 + 2.5;
        elseif code(14) == '5'
            P = 0.62784 + 5;
        else
            P = 0.62784 + 7.5;
        end
        if length(code) >= 18
            type = 3;
            F = str2double(code(end-2:end-1));
            a = 0.63;
        end
    end

    % Assigning correct material properties
    L = 0.96;
    I = Inertia.(material);
    W = 9.81* Weight.(material);
    Working_range = Range.(material);

    X_vals = [Split_data(subset(c)).Table.Distance_m]';
    Y_val = [Split_data(subset(c)).Table.Deflection_m]';
    Y_val = Y_val(2:end);
    
    X_vals = X_vals(2:end);


    %% Method
    E_vals = [190933300691,82656749077,79001523370];%Working_range;%linspace(Working_range(1),Working_range(2),n_curves);
    Y_vals = repmat(Y_val,length(E_vals),1);
    y = [];
    if plot_disp == 1
        figure
        plot(X_vals,Y_val,'rx','markersize',10)
        hold on
    end
    for n = 1:length(E_vals)
        %% Point and Force
        if type == 3
            %% Split
                y_sym = -(1/(24*E_vals(n)*I))*(x^4*W/L-4*x^3*(W+P-F)+6*x^2*(W*L+2*P*L-2*F*a));
                y(n,1:length(X_vals(X_vals<a))) = -(1/(24*E_vals(n)*I))*(X_vals(X_vals<a).^4*W/L-4*X_vals(X_vals<a).^3*(W+P-F)+6*X_vals(X_vals<a).^2*(W*L+2*P*L-2*F*a));
                if plot_disp == 1
                    fplot(y_sym,[0 a])
                end
                grad = -(1/(6*E_vals(n)*I))*(a^3*W/L-3*a^2*(W+P-F)+3*a*(W*L+2*P*L-2*F*a));
                y_at_a = -(1/(24*E_vals(n)*I))*(a^4*W/L-4*a^3*(W+P-F)+6*a^2*(W*L+2*P*L-2*F*a));
                y_sym = grad*(x-a)-(1/(24*E_vals(n)*I))*((x-a)^4*(W/(L-a))-4*(x-a)^3*(W+P)+6*(L-a)*(x-a)^2*(W+2*P))+y_at_a;
                y(n,length(X_vals(X_vals<a))+1:length(X_vals)) = grad*(X_vals(X_vals>a)-a)-(1/(24*E_vals(n)*I))*((X_vals(X_vals>a)-a).^4*(W/(L-a))-4*(X_vals(X_vals>a)-a).^3*(W+P)+6*(L-a)*(X_vals(X_vals>a)-a).^2*(W+2*P))+y_at_a;
                if plot_disp == 1
                    fplot(y_sym,[a 1])
                end
                
                %% Not split
%             y_sym = -((W./(E_vals(n)*I*24*L)).*(x^4-4*L*x^3+6*L^2*x^2)+(P/(E_vals(n)*I))*(3*L*x^2-x^3)+F/(6*E_vals(n)*I)*(3*a*x^2-x^3));
%             y(n,:) = -((W./(E_vals(n)*I*24*L)).*(X_vals.^4-4*L*X_vals.^3+6*L^2*X_vals.^2)+(P/(E_vals(n)*I))*(3*L*X_vals.^2-X_vals.^3)+F/(6*E_vals(n)*I)*(3*a*X_vals.^2-X_vals.^3));
        end
        %% Point only
        if type == 2   
            y_sym = -(1/(E_vals(n)*I))*(W/(24*L))*(x^4-4*L*x^3+6*L^2*x^2)-(P/(6*E_vals(n)*I))*(3*L*x^2-x^3);
            %y_sym = (1/(24*E_vals(n)*I*L))*(W*x^4-4*(P+W)*x^3+(6*L*(2*P + W*L))*x^2);
            y(n,:) = -(1/(E_vals(n)*I))*(W/(24*L))*(X_vals.^4-4*L*X_vals.^3+6*L^2*X_vals.^2)-(P/(6*E_vals(n)*I))*(3*L*X_vals.^2-X_vals.^3);        
            if plot_disp == 1
                fplot(y_sym,[0 1])
            end
        end
        %% Weight Only
        if type == 1  
            y_sym = -(W./(E_vals(n)*I*24*L)).*(x^4-4*L*x^3+6*L^2*x^2);
            y(n,:) = -(W./(E_vals(n)*I*24*L)).*(X_vals.^4-4*L*X_vals.^3+6*L^2*X_vals.^2);
            if plot_disp == 1
                fplot(y_sym,[0 1])
            end
        end
        %% Plotting
        title(code);
    end


    %%
    Error = (y - Y_vals)./Y_vals;
    %%
    Mean_error = sum(Error,2)';
    
    [~,ind(1)] = min(abs(Mean_error));
    ind(2) = ind(1)-1;
    ind(3) = ind(1);
    
    ind(ind<1) = 1;
    if max(ind) > length(E_vals)
        fprintf('/n/nERROR - Increase range of E values')
    end

    
    %error_coeffs = polyfit(E_vals(ind(2):ind(3)),Mean_error(ind(2):ind(3)),1);
    %error_symb = create_sym_funct(error_coeffs);
    if plot_error == 1
        figure
        %fplot(error_symb,[min(E_vals(ind(2):ind(3))) max(E_vals(ind(2):ind(3)))],'b-','linewidth',2) 
        hold on
        plot(E_vals,Mean_error,'rx-')
        grid on
    end
    %%
    E_estimated = polyval(polyfit(Mean_error(ind(2):ind(3)),E_vals(ind(2):ind(3)),1),0);
    fprintf('E of %s = %d Pa \n',subset_names{subset(c)},E_estimated)
    results{c,1} = code;
    results{c,2} = E_estimated;
end
